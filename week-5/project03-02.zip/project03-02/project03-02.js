/*    JavaScript 7th Edition
      Chapter 3
      Project 03-02

      Application to generate a slide gallery
      Author: Chad Smith
      Date: 2026-09-10  

      Filename: project03-02.js
*/

/*
In this project you will generate an image gallery using images of the International Space Station. Each image will be placed within a figure box accompanied by a caption taken from an array of caption text.
*/

/* Captions array */

let captions = new Array(14);
captions[0] = "International Space Station fourth expansion [2009]";
captions[1] = "Assembling the International Space Station [1998]";
captions[2] = "The Atlantis docks with the ISS [2001]";
captions[3] = "The Atlantis approaches the ISS [2000]";
captions[4] = "The Atlantis approaches the ISS [2000]";
captions[5] = "International Space Station over Earth [2002]";
captions[6] = "The International Space Station first expansion [2002]";
captions[7] = "Hurricane Ivan from the ISS [2008]";
captions[8] = "The Soyuz spacecraft approaches the ISS [2005]";
captions[9] = "The International Space Station from above [2006]";
captions[10] = "Maneuvering in space with the Canadarm2 [2006]";
captions[11] = "The International Space Station second expansion [2006]";
captions[12] = "The International Space Station third expansion [2007]";
captions[13] = "The ISS over the Ionian Sea [2007]";

let htmlCode = "";

/*
Create a for loop with a counter that goes from 0 to less the length of the captions array in increments of 1. With each iteration, add the text to the value of the htmlCode variable.
*/

for (let i = 0; i < captions.length; i++) {
  htmlCode += "<figure>";
  htmlCode += "<img alt='' src='slide" + i + ".jpg' />";
  htmlCode += "<figcaption>" + captions[i] + "</figcaption>";
  htmlCode += "</figure>";
}

/* Change the inner HTML of the document element by the id "gallery" to value of the htmlCode variable
 */

document.getElementById("gallery").innerHTML = htmlCode;
